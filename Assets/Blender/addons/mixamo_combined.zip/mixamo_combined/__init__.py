bl_info = {
    "name": "Mixamo Rig 2025",
    "author": "Adobe, Mixanimo Team",
    "version": (2025, 1),
    "blender": (3, 0, 0),
    "location": "3D View > Sidebar > Mixamo Rig",
    "description": "Auto Rig and Animate Mixamo Characters in Blender 3 & 4",
    "warning": "",
    "wiki_url": "",
    "category": "Animation",
}

import bpy, os, importlib

# Dinamik add-on anahtar adı (klasör ismi ne ise o)
ADDON_KEY = __name__.split('.')[0]

# Bu paketin kök dizini
_base_dir = os.path.dirname(__file__)

# Sadece mevcut Blender sürümüne ait alt klasörü __path__ olarak bırak
if bpy.app.version >= (4, 0, 0):
    __path__ = [os.path.join(_base_dir, "mixamo_rig_blender4")]
else:
    __path__ = [os.path.join(_base_dir, "mixamo_rig_blender3")]

# Relative import ile yalnızca bir mixamo_rig modülünü çağır
from .mixamo_rig import register as rig_register, unregister as rig_unregister
from .mixamo_rig_prefs import register as prefs_register, unregister as prefs_unregister

def register():
    prefs_register()
    rig_register()
    # Panel kategorisini kullanıcı tercihlerine göre güncelle
    addon = bpy.context.preferences.addons.get(ADDON_KEY)
    if addon:
        tab = getattr(addon.preferences, "mixamo_tab_name", None)
        if tab:
            mod = importlib.import_module(f"{ADDON_KEY}.mixamo_rig")
            for name in dir(mod):
                cls = getattr(mod, name)
                if hasattr(cls, "bl_category"):
                    cls.bl_category = tab

def unregister():
    rig_unregister()
    prefs_unregister()