# mixanimo_export_fbx.py
import bpy, os
from bpy.types import Operator
from bpy.props import StringProperty, BoolProperty, EnumProperty

def _active_action_name(obj):
    return obj.animation_data.action.name if (obj and obj.animation_data and obj.animation_data.action) else ""

def _enter_pose_select_all(obj):
    vl = bpy.context.view_layer
    vl.objects.active = obj
    for o in bpy.context.selected_objects: o.select_set(False)
    obj.select_set(True)
    if obj.mode != 'POSE': bpy.ops.object.mode_set(mode='POSE')
    for pb in obj.pose.bones: pb.bone.select = True

def _exit_to_object_mode():
    if bpy.context.object and bpy.context.object.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')

def _prebake_selected_armatures(frame_start, frame_end):
    """Visual bake + clear constraints for selected ARMATURE objects."""
    sel_arms = [o for o in bpy.context.selected_objects if o.type == 'ARMATURE']
    if not sel_arms: return False
    for arm in sel_arms:
        _enter_pose_select_all(arm)
        bpy.ops.nla.bake(
            frame_start=int(frame_start), frame_end=int(frame_end),
            only_selected=True, visual_keying=True, clear_constraints=True,
            use_current_action=True, bake_types={'POSE'}
        )
    _exit_to_object_mode()
    return True

def _collect_export_set(context):
    """Selected armatures + onlara bağlı tüm mesh'ler (ve seçili mesh'lerin armature'ları)."""
    sel = set(context.selected_objects)
    armatures = {o for o in sel if o.type == 'ARMATURE'}
    for obj in list(sel):
        if obj.type == 'MESH':
            for m in obj.modifiers:
                if m.type == 'ARMATURE' and m.object:
                    armatures.add(m.object)
    meshes = set()
    for arm in armatures:
        for obj in context.scene.objects:
            if obj.type != 'MESH': continue
            linked = (obj.parent == arm) or any(md.type=='ARMATURE' and md.object==arm for md in obj.modifiers)
            if linked: meshes.add(obj)
    meshes |= {o for o in sel if o.type == 'MESH'}
    return armatures | meshes

def _save_selection_state(context):
    active = context.view_layer.objects.active
    selected = list(context.selected_objects)
    mode = context.object.mode if context.object else 'OBJECT'
    return active, selected, mode

def _restore_selection_state(active, selected, mode):
    for o in bpy.context.selected_objects: o.select_set(False)
    for o in selected:
        if o and o.name in bpy.context.scene.objects: o.select_set(True)
    if active and active.name in bpy.context.scene.objects:
        bpy.context.view_layer.objects.active = active
    if bpy.context.object and bpy.context.object.mode != mode:
        try: bpy.ops.object.mode_set(mode=mode)
        except: pass

def _select_only(objs):
    """Seçimi sadece verilen obje kümesine ayarla (export öncesi güvence)."""
    for o in bpy.context.selected_objects: o.select_set(False)
    for o in objs: o.select_set(True)

class MIXANIMO_OT_export_fbx(Operator):
    bl_idname = "mixanimo.export_fbx"
    bl_label = "Export as FBX (Game-Ready)"
    bl_options = {'REGISTER', 'UNDO'}

    filepath: StringProperty(name="File Path", subtype='FILE_PATH', default="")
    pre_bake: BoolProperty(name="Pre-Bake (Visual + Clear Constraints)", default=True,
                           description="Before export, bake deform bones with visual keying and clear constraints")
    deform_only: BoolProperty(name="Only Deform Bones", default=True,
                              description="Export only deform bones (recommended after Mixamo rig)")
    apply_transform: BoolProperty(name="Apply Transform", default=True)
    bake_anim: BoolProperty(name="Bake Animation", default=True)
    only_active_action: BoolProperty(name="Only Active Action", default=True)

    axis_forward: EnumProperty(name="Forward",
        items=[('-Z', "-Z Forward",""), ('Z',"Z Forward",""), ('-Y',"-Y Forward",""),
               ('Y',"Y Forward",""), ('-X',"-X Forward",""), ('X',"X Forward","")],
        default='-Z')
    axis_up: EnumProperty(name="Up", items=[('Y',"Y Up",""), ('Z',"Z Up","")], default='Y')

    def invoke(self, context, event):
        dirname = bpy.path.abspath("//")
        base = "mixanimo_export"
        arm = context.active_object if (context.active_object and context.active_object.type=='ARMATURE') else None
        act = _active_action_name(arm) if arm else ""
        if act: base = f"{arm.name}_{act}"
        self.filepath = os.path.join(dirname, f"{base}.fbx")
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        if not self.filepath: 
            self.report({'ERROR'}, "Please choose a filepath ending with .fbx"); return {'CANCELLED'}
        root, ext = os.path.splitext(self.filepath)
        if ext.lower() != ".fbx": self.filepath = root + ".fbx"

        if not context.selected_objects:
            self.report({'ERROR'}, "Nothing selected. Select the armature or a bound mesh and try again.")
            return {'CANCELLED'}

        export_set = _collect_export_set(context)
        if not export_set:
            self.report({'ERROR'}, "No linked mesh/armature pair found."); return {'CANCELLED'}

        prev_active, prev_selected, prev_mode = _save_selection_state(context)
        _select_only(export_set)
        any_arm = next((o for o in export_set if o.type=='ARMATURE'), None)
        if any_arm: context.view_layer.objects.active = any_arm
        _exit_to_object_mode()

        # --- PRE-BAKE ---
        if self.pre_bake:
            scene = context.scene
            fs, fe = scene.frame_start, scene.frame_end
            for o in export_set:
                if o.type=='ARMATURE' and o.animation_data and o.animation_data.action:
                    a = o.animation_data.action; fs, fe = int(a.frame_range[0]), int(a.frame_range[1]); break
            try:
                _prebake_selected_armatures(fs, fe)
            except Exception as e:
                self.report({'WARNING'}, f"Pre-Bake skipped: {e}")

            # ⚠️ ÖNEMLİ: Pre-Bake seçimleri bozduğu için burada tekrar hepsini seçiyoruz
            _select_only(export_set)
            if any_arm: context.view_layer.objects.active = any_arm
            _exit_to_object_mode()

        # --- EXPORT ---
        try:
            bpy.ops.export_scene.fbx(
                filepath=self.filepath,
                use_selection=True,
                add_leaf_bones=False,
                apply_unit_scale=True,
                apply_scale_options='FBX_SCALE_ALL',
                bake_space_transform=self.apply_transform,
                use_armature_deform_only=self.deform_only,
                armature_nodetype='ROOT',
                object_types={'ARMATURE','MESH'},
                mesh_smooth_type='FACE',
                axis_forward=self.axis_forward,
                axis_up=self.axis_up,
                bake_anim=self.bake_anim,
                bake_anim_use_all_actions=not self.only_active_action,
                bake_anim_use_nla_strips=False,
                bake_anim_simplify_factor=0.0,
            )
        except Exception as e:
            self.report({'ERROR'}, f"FBX export failed: {e}")
            _restore_selection_state(prev_active, prev_selected, prev_mode)
            return {'CANCELLED'}

        _restore_selection_state(prev_active, prev_selected, prev_mode)
        self.report({'INFO'}, f"Exported FBX → {self.filepath}\nImport hint: Armature→ Ignore Leaf Bones ✓, Automatic Bone Orientation ✗")
        return {'FINISHED'}

classes = (MIXANIMO_OT_export_fbx,)

def register():
    for c in classes: bpy.utils.register_class(c)

def unregister():
    for c in reversed(classes): bpy.utils.unregister_class(c)