bl_info = {
    "name": "Mixanimo Pro",
    "author": "Mixanimo Team",
    "version": (1, 0, 0),
    "blender": (3, 5, 0),
    "location": "View3D > Sidebar > Mixanimo Tools",
    "description": "Manage and customize Mixamo animation transitions.",
    "category": "Animation"
}

# ===============================================================================
# MIT License
# 
# Copyright (c) 2025 Mixanimo Team
# Contact: mixanimoaddon@gmail.com
# 
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
# 
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
# ===============================================================================

import bpy
from mathutils import Vector
from bpy.types import (
    Panel,
    Operator,
    PropertyGroup,
    UIList
)
from bpy.props import (
    StringProperty,
    CollectionProperty,
    IntProperty,
    BoolProperty,
    EnumProperty         # --- EKLENDİ ---
)
from bpy.app.handlers import persistent

# >>> YENİ: Export modülünü içe aktar <<<
from . import mixanimo_export_fbx

# ===========================
# GEREKLİ CLASS (EKLENDİ!)
# ===========================
class MIXAMO_UL_ActionList(UIList):
    pass

#####################################################
# Helper Functions
#####################################################

from mathutils import Vector, Quaternion, Euler
import math

def get_local_location_at_frame(action, bone_name, frame):
    loc = [0.0, 0.0, 0.0]
    data_path = f'pose.bones["{bone_name}"].location'
    for fc in action.fcurves:
        if fc.data_path == data_path:
            idx = fc.array_index
            loc[idx] = fc.evaluate(frame)
    return Vector(loc)

def get_action_start_location_local(action, bone_name):
    start_frame = int(action.frame_range[0])
    return get_local_location_at_frame(action, bone_name, start_frame)

def get_action_end_location_local(action, bone_name):
    end_frame = int(action.frame_range[1])
    return get_local_location_at_frame(action, bone_name, end_frame)

def offset_action_root_local(action, bone_name, offset_vec):
    data_path = f'pose.bones["{bone_name}"].location'
    fcurves = [fc for fc in action.fcurves if fc.data_path == data_path]
    if fcurves:
        for i, fc in enumerate(fcurves):
            for kp in fc.keyframe_points:
                if i < len(offset_vec):
                    kp.co[1] += offset_vec[i]
            fc.update()
    else:
        print(f"Warning: No fcurves found for bone '{bone_name}' in action '{action.name}'.")

def create_action_copy(original_action, repeat_index=1):
    new_action = original_action.copy()
    new_action.name = f"{original_action.name}_REPEAT_{repeat_index}"
    return new_action

def get_quat_axis(forward_axis):
    if forward_axis == 'X+':
        return (1, 0, 0)
    elif forward_axis == 'X-':
        return (-1, 0, 0)
    elif forward_axis == 'Y+':
        return (0, 1, 0)
    elif forward_axis == 'Y-':
        return (0, -1, 0)
    elif forward_axis == 'Z+':
        return (0, 0, 1)
    elif forward_axis == 'Z-':
        return (0, 0, -1)
    else:
        return (0, 1, 0)  # Varsayılan Y+

def offset_action_root_rotation(action, bone_name, offset_angle_deg, forward_axis='Y+'):
    """
    Tüm keyframeleri, kullanıcıdan alınan forward_axis etrafında
    offset_angle_deg kadar döndürür (delta).
    """
    data_path = f'pose.bones["{bone_name}"].rotation_quaternion'
    fcurves = [fc for fc in action.fcurves if fc.data_path == data_path]
    if len(fcurves) == 4:
        angle_rad = math.radians(offset_angle_deg)
        quat_axis = get_quat_axis(forward_axis)
        rot_quat = Quaternion(quat_axis, angle_rad)
        key_count = len(fcurves[0].keyframe_points)
        for i in range(key_count):
            frame = fcurves[0].keyframe_points[i].co[0]
            quat = Quaternion([fc.evaluate(frame) for fc in fcurves])
            new_quat = rot_quat @ quat
            for j, fc in enumerate(fcurves):
                fc.keyframe_points[i].co[1] = new_quat[j]
            fc.update()
    else:
        print(f"Warning: Quaternion rotation fcurves not found for bone '{bone_name}' in action '{action.name}'.")

#####################################################
# 1) SEND TO TIMELINE (DIRECTION & POSITION ENTEGRE)
#####################################################

def rotate_action_root_location(action, bone_name, angle_deg, forward_axis='Y+'):
    """
    Root bone'un tüm location anahtarlarını, verilen eksende angle_deg kadar döndürür.
    """
    angle_rad = math.radians(angle_deg)
    axis = get_quat_axis(forward_axis)
    rot_quat = Quaternion(axis, angle_rad)
    data_path = f'pose.bones["{bone_name}"].location'
    fcurves = [fc for fc in action.fcurves if fc.data_path == data_path]
    if len(fcurves) == 3:
        key_count = len(fcurves[0].keyframe_points)
        for i in range(key_count):
            loc = Vector([fcurves[j].keyframe_points[i].co[1] for j in range(3)])
            new_loc = rot_quat @ loc
            for j in range(3):
                fcurves[j].keyframe_points[i].co[1] = new_loc[j]
            for fc in fcurves:
                fc.update()
    else:
        print(f"Warning: Location fcurves not found for bone '{bone_name}' in action '{action.name}'.")

def send_to_timeline(armature, actions, root_bone="mixamorig:Hips", overlap_frames=3, forward_axis='Y+'):
    """
    Kullanıcı tarafından girilen animasyonları ve açı değerlerini (rotation_angle),
    Blender NLA Editor'de üst üste doğru şekilde ekler.
    Her action'ın root bone'u pozisyon ve seçilen forward_axis etrafında verilen derece kadar döndürülür.
    """
    if armature.animation_data:
        armature.animation_data_clear()
    armature.animation_data_create()

    prev_end_loc = Vector((0, 0, 0))
    current_start = 1
    track_index = 1

    for idx, (act, repeats, angle_deg) in enumerate(actions):
        track = armature.animation_data.nla_tracks.new()
        track.name = f"Track_{track_index}_{act.name}"
        track_index += 1

        for r in range(repeats):
            new_act = create_action_copy(act, repeat_index=r+1)
            length = int(new_act.frame_range[1] - new_act.frame_range[0])

            # --- ROTASYON offset uygula (artık derece ile!) ---
            offset_action_root_rotation(new_act, root_bone, angle_deg, forward_axis=forward_axis)
            # --- LOKASYON vektörünü de aynı miktarda döndür! ---
            rotate_action_root_location(new_act, root_bone, angle_deg, forward_axis=forward_axis)

            # --- KONUM offset uygula ---
            if idx == 0 and r == 0:
                strip_start = current_start
            elif r == 0:
                strip_start = current_start - overlap_frames
                if strip_start < 1:
                    strip_start = 1
            else:
                strip_start = current_start

            strip_end = strip_start + length
            strip_start_int = int(round(strip_start))
            strip_end_int = int(round(strip_end))

            strip = track.strips.new(new_act.name, strip_start_int, new_act)
            strip.frame_start = strip_start_int
            strip.frame_end = strip_end_int

            if idx > 0 and r == 0:
                strip.blend_in = overlap_frames
                strip.blend_out = 0
                strip.blend_type = 'REPLACE'
            else:
                strip.blend_in = 0
                strip.blend_out = 0

            start_loc = get_action_start_location_local(new_act, root_bone)
            if idx > 0 or r > 0:
                offset = prev_end_loc - start_loc
                offset_action_root_local(new_act, root_bone, offset)
            else:
                offset = Vector((0, 0, 0))

            prev_end_loc = get_action_end_location_local(new_act, root_bone)
            current_start = strip_end_int

#####################################################
# PROPERTY GROUP & UIList
#####################################################

def action_index_update(self, context):
    if self.action_index < 0 or self.action_index >= len(self.action_collection):
        return
    item = self.action_collection[self.action_index]
    arm_name = item.armature_name
    if arm_name and arm_name in bpy.data.objects:
        arm_obj = bpy.data.objects[arm_name]
        bpy.ops.object.select_all(action='DESELECT')
        arm_obj.select_set(True)
        context.view_layer.objects.active = arm_obj

def mixanimo_edit_action_name_update(self, context):
    if hasattr(self, "editing") and self.editing:
        self.needs_confirm = self.edit_action_name.strip() and self.edit_action_name != self.action_name

class MixamoActionItem(PropertyGroup):
    action_name: StringProperty()
    armature_name: StringProperty(default="")
    use_action: BoolProperty(
        name="",
        description="Enable Action",
        default=True
    )
    repeat_count: IntProperty(
        name="Count",
        description=" Repeat Count",
        default=1,
        min=1,
        max=999
    )
    # ----------- EKLENENLER -----------
    edit_action_name: StringProperty(
        default="", update=mixanimo_edit_action_name_update
    )
    editing: BoolProperty(default=False)
    needs_confirm: BoolProperty(default=False)
    # ----------- YÖN ENUMU KALDIRILDI, DERECE EKLENDİ -----------
    rotation_angle: bpy.props.FloatProperty(
        name="Angle (°)",
        description="Rotation (in degrees) to apply before this animation",
        default=0.0,
        step=10,
        precision=2,
        soft_min=-360.0,
        soft_max=360.0
    )

class MixamoUnifiedSettings(PropertyGroup):
    root_bone: StringProperty(
        name="Root Bone",
        description="Name of the root bone (usually 'mixamorig:Hips' in Mixamo)",
        default="mixamorig:Hips"
    )
    overlap_frames: IntProperty(
        name="Overlap Frames",
        description="Number of frames used for blending between strips",
        default=3,
        min=0,
        max=100
    )
    action_collection: CollectionProperty(type=MixamoActionItem)
    action_index: IntProperty(
        default=0,
        update=action_index_update
    )
    order_confirmed: BoolProperty(default=False)
    # -------------- YENİ: FORWARD AXIS EKLENDİ --------------
    forward_axis: EnumProperty(
        name="Character Forward Axis (Beta)",
        description="The direction the character is facing in the scene (Forward)",
        items=[
            ('X+', "X+", ""),
            ('X-', "X-", ""),
            ('Y+', "Y+", ""),
            ('Y-', "Y-", ""),
            ('Z+', "Z+", ""),
            ('Z-', "Z-", ""),
        ],
        default='Y+'
    )

#####################################################
# EKLENEN YENİ OPERATOR – Armature’yi Sahnede Seç
#####################################################

class MIXAMO_OT_SelectArmatureFromList(bpy.types.Operator):
    bl_idname = "mixamo.select_armature_from_list"
    bl_label = "Select Armature"
    armature_name: bpy.props.StringProperty()

    def execute(self, context):
        armature = bpy.data.objects.get(self.armature_name)
        if armature and armature.type == "ARMATURE":
            bpy.ops.object.select_all(action='DESELECT')
            armature.select_set(True)
            context.view_layer.objects.active = armature
            self.report({'INFO'}, f"{self.armature_name} selected.")
        else:
            self.report({'WARNING'}, f"Armature '{self.armature_name}' not found.")
        return {'FINISHED'}

#####################################################
# OPERATORS
#####################################################

class MIXAMO_OT_GetActions(Operator):
    bl_idname = "mixamo.get_actions"
    bl_label = "Load Actions"
    bl_description = "List actions in the scene"
    
    def execute(self, context):
        prefs = context.scene.mixamo_unified
        prefs.action_collection.clear()
        
        for act in bpy.data.actions:
            if "_REPEAT_" not in act.name:
                for fc in act.fcurves:
                    if "pose.bones[" in fc.data_path:
                        item = prefs.action_collection.add()
                        item.action_name = act.name
                        for obj in bpy.data.objects:
                            if obj.type == 'ARMATURE' and obj.animation_data:
                                if obj.animation_data.action == act:
                                    item.armature_name = obj.name
                                    break
                        break
        
        prefs.order_confirmed = False
        self.report({'INFO'}, "Actions loaded. (Armature references assigned if found.)")
        return {'FINISHED'}

class MIXAMO_OT_MoveActionUp(Operator):
    bl_idname = "mixamo.move_action_up"
    bl_label = "Move Action Up"
    
    def execute(self, context):
        prefs = context.scene.mixamo_unified
        idx = prefs.action_index
        if idx > 0:
            prefs.action_collection.move(idx, idx-1)
            prefs.action_index -= 1
            prefs.order_confirmed = False
        return {'FINISHED'}

class MIXAMO_OT_MoveActionDown(Operator):
    bl_idname = "mixamo.move_action_down"
    bl_label = "Move Action Down"
    
    def execute(self, context):
        prefs = context.scene.mixamo_unified
        idx = prefs.action_index
        if idx < len(prefs.action_collection) - 1:
            prefs.action_collection.move(idx, idx+1)
            prefs.action_index += 1
            prefs.order_confirmed = False
        return {'FINISHED'}

class MIXAMO_OT_ConfirmOrder(Operator):
    bl_idname = "mixamo.confirm_order"
    bl_label = "Confirm Order"
    bl_description = "Assign selected actions to active Armature in specified order."
    
    def execute(self, context):
        prefs = context.scene.mixamo_unified
        if len(prefs.action_collection) == 0:
            self.report({'WARNING'}, "No action found.")
            return {'CANCELLED'}
        
        first_item = prefs.action_collection[0]
        if first_item.armature_name and first_item.armature_name in bpy.data.objects:
            arm = bpy.data.objects[first_item.armature_name]
            bpy.context.view_layer.objects.active = arm
            arm.select_set(True)
        else:
            self.report({'WARNING'}, "No armature assigned to the first action")
            return {'CANCELLED'}
        
        prefs.order_confirmed = True
        
        found_any = False
        for item in prefs.action_collection:
            if item.use_action:
                act = bpy.data.actions.get(item.action_name)
                if act:
                    found_any = True
        
        if found_any:
            self.report({'INFO'}, "Order confirmed. Actions ready.")
        else:
            self.report({'INFO'}, "No action selected (use_action).")
        
        return {'FINISHED'}

#####################################################
# MIXAMO_OT_SendToTimeline OPERATOR (DIRECTION ENTEGRE EDİLDİ)
#####################################################

class MIXAMO_OT_SendToTimeline(Operator):
    bl_idname = "mixamo.send_to_timeline"
    bl_label = "Send to Timeline"
    bl_description = "Add selected actions to NLA editor in overlapped sequence."
    
    def execute(self, context):
        prefs = context.scene.mixamo_unified
        if not prefs.order_confirmed:
            self.report({'WARNING'}, "Run 'Confirm Order' before proceeding")
            return {'CANCELLED'}
        
        arm = context.active_object
        if not arm or arm.type != 'ARMATURE':
            self.report({'WARNING'}, "Please select an armature")
            return {'CANCELLED'}
        
        actions_to_send = []
        for item in prefs.action_collection:
            if item.use_action:
                act = bpy.data.actions.get(item.action_name)
                if act:
                    # ------ YÖN (DIRECTION) DEĞERİ DE EKLENDİ ------
                    actions_to_send.append((act, item.repeat_count, item.rotation_angle))
        
        if not actions_to_send:
            self.report({'WARNING'}, "No action selected (use_action=True). Operation cancelled")
            return {'CANCELLED'}
        
        send_to_timeline(arm, actions_to_send, root_bone=prefs.root_bone, overlap_frames=prefs.overlap_frames)
        
        self.report({'INFO'}, f"{len(actions_to_send)} action entry(ies) sent to timeline (multi-track).")
        return {'FINISHED'}

#####################################################
# MIXAMO_OT_SendToTimeline OPERATOR SONU
#####################################################

class MIXAMO_OT_BakeToAction(Operator):
    bl_idname = "mixamo.bake_to_action"
    bl_label = "Bake to Action"
    bl_description = "Bake all NLA strips into a single action for export or reuse."
    bl_description = (
        "Bakes NLA strips on the timeline into a single action "
        "Creates one complete action from your final animation"
    )
    
    def execute(self, context):
        arm = context.active_object
        if not arm or arm.type != 'ARMATURE':
            self.report({'WARNING'}, "An armature must be selected")
            return {'CANCELLED'}
        anim_data = arm.animation_data
        if not anim_data:
            self.report({'WARNING'}, "No anim_data found on this armature")
            return {'CANCELLED'}
        
        min_frame = None
        max_frame = None
        for track in anim_data.nla_tracks:
            for strip in track.strips:
                if min_frame is None or strip.frame_start < min_frame:
                    min_frame = strip.frame_start
                if max_frame is None or strip.frame_end > max_frame:
                    max_frame = strip.frame_end
        
        if min_frame is None or max_frame is None:
            self.report({'WARNING'}, "No strips found in the NLA Editor")
            return {'CANCELLED'}
        
        start_frame = int(round(min_frame))
        end_frame = int(round(max_frame))
        
        try:
            bpy.ops.nla.bake(
                frame_start=start_frame,
                frame_end=end_frame,
                only_selected=False,
                visual_keying=True,
                clear_constraints=False,
                use_current_action=True,
                bake_types={'POSE'}
            )
        except Exception as e:
            self.report({'WARNING'}, f"Bake operation failed with the following error: {e}")
            return {'CANCELLED'}
        
        self.report({'INFO'}, f"Bake completed: from frame {start_frame} to {end_frame}")
        return {'FINISHED'}


class MIXAMO_OT_CleanGraph(Operator):
    bl_idname = "mixamo.clean_graph"
    bl_label = "Stabilize Root"
    bl_description = "Keeps the character fixed by locking root bone position (use after Bake Action)"

    def execute(self, context):
        action = context.object.animation_data.action if context.object and context.object.animation_data else None
        if not action:
            self.report({'WARNING'}, "No active action to clean.")
            return {'CANCELLED'}

        spike_threshold = 5.0  # units in meters
        fixed = 0

        for fc in action.fcurves:
            if "location" in fc.data_path and "mixamorig:Hips" in fc.data_path:
                start_frame = int(action.frame_range[0])
                start_value = fc.evaluate(start_frame)
                for kp in fc.keyframe_points:
                    kp.co[1] = start_value
                fc.update()

        self.report({'INFO'}, f"Clean Graph completed: {fixed} keyframes normalized.")
        return {'FINISHED'}


@persistent
def sync_selection_from_armature(scene):
    prefs = bpy.context.scene.mixamo_unified
    arm = bpy.context.view_layer.objects.active
    
    if not arm or arm.type != 'ARMATURE':
        return
    if not arm.animation_data or not arm.animation_data.action:
        return
    
    current_action = arm.animation_data.action
    for i, item in enumerate(prefs.action_collection):
        if item.action_name == current_action.name:
            if prefs.action_index != i:
                prefs.action_index = i
            break
# ----------- EKLENEN OPERATÖRLER -----------

class MIXAMO_OT_StartRenameAction(bpy.types.Operator):
    bl_idname = "mixamo.start_rename_action"
    bl_label = "Start Rename Action"
    index: IntProperty()

    def execute(self, context):
        prefs = context.scene.mixamo_unified
        item = prefs.action_collection[self.index]
        item.edit_action_name = item.action_name
        item.editing = True
        item.needs_confirm = False
        return {'FINISHED'}

class MIXAMO_OT_CancelRenameAction(bpy.types.Operator):
    bl_idname = "mixamo.cancel_rename_action"
    bl_label = "Cancel Rename Action"
    index: IntProperty()

    def execute(self, context):
        prefs = context.scene.mixamo_unified
        item = prefs.action_collection[self.index]
        item.editing = False
        item.needs_confirm = False
        item.edit_action_name = item.action_name
        return {'FINISHED'}

class MIXAMO_OT_RenameAction(bpy.types.Operator):
    bl_idname = "mixamo.rename_action"
    bl_label = "Rename Action"
    index: IntProperty()

    def execute(self, context):
        prefs = context.scene.mixamo_unified
        item = prefs.action_collection[self.index]
        new_name = item.edit_action_name.strip()
        old_name = item.action_name
        if new_name and new_name != old_name and new_name not in bpy.data.actions:
            act = bpy.data.actions.get(old_name)
            if act:
                act.name = new_name
            item.action_name = new_name
            item.editing = False
            item.needs_confirm = False
            item.edit_action_name = new_name
            self.report({'INFO'}, "Action name changed.")
        else:
            self.report({'WARNING'}, "Invalid or duplicate name.")
        return {'FINISHED'}

#####################################################
# PANEL & UIList: Action İsmi Panelden Düzenleme Destekli
#####################################################

class MIXAMO_UL_ActionList_Edit(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)
            row.prop(item, "use_action", text="")
            if hasattr(item, "editing") and item.editing:
                row.prop(item, "edit_action_name", text="", emboss=True, icon='GREASEPENCIL')
                if item.needs_confirm and item.edit_action_name.strip() and item.edit_action_name != item.action_name:
                    confirm = row.operator("mixamo.rename_action", text="", icon='CHECKMARK', emboss=True)
                    confirm.index = index
                else:
                    row.label(text="", icon='BLANK1')
                cancel = row.operator("mixamo.cancel_rename_action", text="", icon='X', emboss=True)
                cancel.index = index
            else:
                row.label(text=item.action_name, icon='ACTION')
                edit = row.operator("mixamo.start_rename_action", text="", icon='GREASEPENCIL', emboss=False)
                edit.index = index
            if item.armature_name:
                row.label(text=f"[{item.armature_name}]", icon='ARMATURE_DATA')
                op = row.operator("mixamo.select_armature_from_list", text="", icon="RESTRICT_SELECT_OFF", emboss=False)
                op.armature_name = item.armature_name
            act = bpy.data.actions.get(item.action_name)
            if act:
                row.label(text=f"{int(act.frame_range[1] - act.frame_range[0])} fr", icon='TIME')
            row.prop(item, "repeat_count", text="x")
            # --- DIRECTION DROPDOWN KALDIRILDI, DERECE EKLENDİ ---
            row.prop(item, "rotation_angle", text="")
        elif self.layout_type == 'GRID':
            pass

class MIXAMO_PT_UnifiedPanel(Panel):
    bl_label = "MIXANIMO"
    bl_idname = "MIXAMO_PT_unified_merger"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Mixanimo Tools"

    def draw(self, context):
        layout = self.layout
        layout.label(text="Load & Organize Animations", icon="ANIM")
        layout.separator()
        prefs = context.scene.mixamo_unified
        
        # ----------- YENİ: FORWARD AXIS DROPDOWN -----------
        row = layout.row()
        row.prop(prefs, "forward_axis", text="Character Forward Axis")
        # ---------------------------------------------------

        row = layout.row()
        row.operator("mixamo.get_actions", text="Load Actions", icon='FILE_REFRESH')
        
        row = layout.row()
        row.template_list(
            "MIXAMO_UL_ActionList_Edit",   # DEĞİŞTİ!
            "",
            prefs,
            "action_collection",
            prefs,
            "action_index",
            rows=5
        )
        col = row.column(align=True)
        col.operator("mixamo.move_action_up", icon='TRIA_UP', text="")
        col.operator("mixamo.move_action_down", icon='TRIA_DOWN', text="")
        
        box = layout.box()
        box.prop(prefs, "root_bone", text="Root Bone")
        box.prop(prefs, "overlap_frames", text="Overlap Frames")
        box.operator("mixamo.confirm_order", text="Confirm Order", icon='CHECKMARK')

        layout.separator()

        layout.label(text="Nonlinear Animation", icon="NLA")
        layout.separator()
        row = layout.row(align=True)
        row.operator("mixamo.send_to_timeline", text="Send", icon='NLA')
        row.operator("mixamo.bake_to_action", text="Bake Action", icon='ACTION')
        row.operator("mixamo.clean_graph", text="Stabilize Root", icon="GRAPH")

        # --- YENİ: Export FBX Butonu ---
        layout.separator()
        layout.operator("mixanimo.export_fbx", icon="EXPORT", text="Export as FBX (Game-Ready)")


classes = (
    MixamoActionItem,
    MixamoUnifiedSettings,
    MIXAMO_UL_ActionList,
    MIXAMO_UL_ActionList_Edit,       # YENİ UIList
    MIXAMO_OT_GetActions,
    MIXAMO_OT_MoveActionUp,
    MIXAMO_OT_MoveActionDown,
    MIXAMO_OT_ConfirmOrder,
    MIXAMO_OT_SendToTimeline,
    MIXAMO_OT_BakeToAction,
    MIXAMO_OT_CleanGraph,
    MIXAMO_PT_UnifiedPanel,
    MIXAMO_OT_SelectArmatureFromList,
    MIXAMO_OT_StartRenameAction,     # Action isim düzenleme: başlat
    MIXAMO_OT_CancelRenameAction,    # Action isim düzenleme: iptal
    MIXAMO_OT_RenameAction,          # Action isim düzenleme: onayla
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.mixamo_unified = bpy.props.PointerProperty(type=MixamoUnifiedSettings)
    if sync_selection_from_armature not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(sync_selection_from_armature)

    # --- Export FBX modülünü kaydet ---
    mixanimo_export_fbx.register()


def unregister():
    if sync_selection_from_armature in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(sync_selection_from_armature)
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.mixamo_unified

    # --- Export FBX modülünü kaldır ---
    mixanimo_export_fbx.unregister()


if __name__ == "__main__":
    register()